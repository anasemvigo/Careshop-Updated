var config = {
	paths: {
		'rudracomputech/ezplus'	: 'Careshop_Reviews/js/plugins/jquery/jquery.ez-plus',
	},
	shim: {
		'rudracomputech/ezplus': {
			deps: ['jquery']
		}
	}
};