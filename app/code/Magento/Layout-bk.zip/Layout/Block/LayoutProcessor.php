<?php

namespace Magento\Layout\Block;

class LayoutProcessor implements \Magento\Checkout\Block\Checkout\LayoutProcessorInterface
{
    public function process($jsLayout)
    {
        if (isset($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children'])) {
            $fields =$jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children'];

            if( isset($fields['company']) )
                $fields['company']['sortOrder'] = 16;

            if( isset($fields['gender_field']) )
                $fields['gender_field']['sortOrder'] = 18;        

            if( isset($fields['postcode']) ){
                $fields['postcode']['validation']['required-entry'] = 1;
                $fields['postcode']['sortOrder'] = 98;
            }
            if( isset($fields['city']) )
                $fields['city']['validation']['required-entry'] = 1;

            $fields['date_of_birth'] = [
                'component' => 'Magento_Ui/js/form/element/abstract',
                'config' => [
                    'customScope' => 'shippingAddress',
                    'template' => 'ui/form/field',
                    'elementTmpl' => 'ui/form/element/date',
                    'options' => [
								'changeYear'=> true,
								'changeMonth'=> true,
								'yearRange' => '1950:2050'
								],
                    'id' => 'date_of_birth'
                ],
                'validation' => ['required-entry'=>true], 
                'dataScope' => 'shippingAddress.date_of_birth',
                'label' => 'Date of Birth',
                'provider' => 'checkoutProvider',
                'placeholder' => 'DD/MM/YY',
                'visible' => true,
                'sortOrder' => 42,
          
                'id' => 'date_of_birth'
            ];

            $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']
            ['children']['shippingAddress']['children']['shipping-address-fieldset']['children'] =  $fields;
          
           
        }
        return $jsLayout;
    }
}
